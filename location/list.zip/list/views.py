from datetime import datetime

from django.shortcuts import render, get_object_or_404, redirect,HttpResponse
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.core.mail import send_mail


User = get_user_model()

from .models import Voiture, Reservation, Client, Commentaire

# Create your views here.


def index(request):
    cars = Voiture.objects.all()
    return render(request, "list/index.html", context={"cars": cars})


def car_detail(request, slug):
    car = get_object_or_404(Voiture, slug=slug)

    if request.method == 'POST':
        # Récupérer les valeurs du formulaire
        avec_chauffeur = request.POST.get('chauffeur') == "avec chauffeur"
        region = request.POST.get('region')
        lieu = request.POST.get('lieu')
        date_deb = request.POST.get('date_deb')
        date_fin = request.POST.get('date_fin')

        try:
            # Conversion des dates en objets datetime pour comparaison
            date_deb = datetime.strptime(date_deb, "%Y-%m-%d")
            date_fin = datetime.strptime(date_fin, "%Y-%m-%d")
        except ValueError:
            messages.error(request, "Format de date invalide. Veuillez entrer une date au format AAAA-MM-JJ.")
            return render(request, 'list/detail.html', context={'car': car})

        # Vérification des dates
        now = datetime.now()
        if date_deb > date_fin:
            messages.error(request, "La date de début ne peut pas être après la date de fin.")
        elif date_deb < now or date_fin < now:
            messages.error(request, "Les dates doivent être dans le futur.")
        else:
            # Si tout est valide, créer les enregistrements
            user = Client(nom=request.user)
            user.save()

            reserve = Reservation(
                region=region,
                avec_chauffeur=avec_chauffeur,
                lieu=lieu,
                deb_location=date_deb,
                fin_location=date_fin,
                client=user,
                voiture=car
            )
            reserve.save()

            # Envoi de l'email
            send_mail(
                subject="Nouvelle Réservation",
                message=f"Une nouvelle réservation a été effectuée pour la voiture {car.model}. "
                        f"Début : {date_deb}, Fin : {date_fin}, Point de livraison : {lieu}.",
                from_email=request.user.email,
                recipient_list=["elonovacar@gmail.com", "urbainbalogou19@gmail.com"],
                fail_silently=False,
            )

            messages.success(request, "Réservation effectuée avec succès.")
            return render(request, "list/succes_page.html")

        # Si des erreurs sont détectées, rester sur la même page
        return render(request, 'list/detail.html', context={'car': car})

    elif request.method == 'GET':
        comment = request.GET.get('commentaire')
        if comment:
            user = Client(nom=request.user)
            commentaire = Commentaire(client=user, voiture=car, content=comment)
            user.save()
            commentaire.save()
            messages.success(request, "Commentaire ajouté avec succès.")
            return render(request, 'list/detail.html', context={'car': car})

    return render(request, 'list/detail.html', context={'car': car})









# Create your views here.
